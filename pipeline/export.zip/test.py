import os


def lambda_handler():
    print(os.environ)
